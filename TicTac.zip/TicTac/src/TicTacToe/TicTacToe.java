package TicTacToe;

public class TicTacToe {
    
    public static void main(String[] args) {
        new Menu();
    }
}
